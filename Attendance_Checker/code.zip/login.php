<?php
header('Content-Type: application/json');
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$idnumber = $mysqli->real_escape_string($data['idnumber']);
$password = $data['password'];

$res = $mysqli->query("SELECT * FROM users WHERE idnumber='$idnumber' LIMIT 1");
if ($res->num_rows == 0) {
    echo json_encode(["success" => false, "error" => "ID number not found."]);
    exit;
}
$user = $res->fetch_assoc();

if ($user['password'] == "") {
    echo json_encode(["success" => false, "set_password" => true]);
    exit;
}

if ($user['password'] === $password) {
    unset($user['password']);
    echo json_encode(["success" => true, "user" => $user]);
} else {
    echo json_encode(["success" => false, "error" => "Invalid password."]);
}
?>