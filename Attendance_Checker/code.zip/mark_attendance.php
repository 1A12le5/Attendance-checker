<?php
header('Content-Type: application/json');
require 'db.php';

$data = json_decode(file_get_contents("php://input"), true);
$date = $mysqli->real_escape_string($data['date']);
$attendance = $data['attendance']; // array of {student_id, status}

$mysqli->query("DELETE FROM attendance WHERE date='$date'");

foreach ($attendance as $rec) {
    $student_id = intval($rec['student_id']);
    $status = $mysqli->real_escape_string($rec['status']);
    $mysqli->query("INSERT INTO attendance (date, student_id, status) VALUES ('$date', $student_id, '$status')");
}

echo json_encode(["success" => true]);
?>